import java.io.File;

public class JavaBiometric {

  public JavaBiometric() {
  }
  public static void main(String[] args) {
	  
    CEntityForm classFormMain = new CEntityForm();
    //classFormMain.setSize(400,700);
    classFormMain.setVisible(true);
  }
}