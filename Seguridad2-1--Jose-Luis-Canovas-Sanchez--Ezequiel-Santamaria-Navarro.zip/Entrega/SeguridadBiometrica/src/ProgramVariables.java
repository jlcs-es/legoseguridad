/**
 * Created by JoséLuis on 26/02/2016.
 */
public class ProgramVariables {
    public static int NUMBER_OF_POINTS = 65;
    public static double PERCENTAGE_OF_SIMILARITY = 45.0;
}
