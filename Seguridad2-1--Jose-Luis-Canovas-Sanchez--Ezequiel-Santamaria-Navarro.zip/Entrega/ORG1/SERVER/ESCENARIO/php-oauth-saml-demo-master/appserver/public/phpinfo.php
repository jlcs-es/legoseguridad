<?php
phpinfo();
?>
<hr />
<pre>
<?php
print_r(apache_request_headers());
?>
</pre>